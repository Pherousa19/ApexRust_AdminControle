function money(cents) {
  return "£" + ((cents || 0) / 100).toFixed(2);
}

function fmtDate(str) {
  if (!str) return "—";
  return str.replace("T", " ").slice(0, 16);
}

function esc(str) {
  return String(str ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

// The DB/URL slug for this category stays "ranks" (schema, product IDs,
// /ranks route) — only the label shown to admins/customers changed to
// "Subscriptions" to match how the store actually uses it now (one-time
// AND recurring products can both live in any category, including this one).
const CATEGORY_LABELS = { kits: "Kits", packages: "Packages", items: "Items", ranks: "Subscriptions" };

// Maps the raw payment_method value stored on an order to something
// readable in the admin table. Stripe's own type strings (card, klarna,
// link, ...) pass through title-cased; the store's own gift-card-only and
// gift-card-assisted payments get explicit labels.
const PAYMENT_METHOD_LABELS = {
  card: "Card",
  gift_card: "Gift Card",
  "card+gift_card": "Card + Gift Card",
  link: "Link",
  klarna: "Klarna",
};

function paymentMethodLabel(value) {
  if (!value) return "Card";
  return PAYMENT_METHOD_LABELS[value] || value.split("+").map((p) => p.charAt(0).toUpperCase() + p.slice(1).replace(/_/g, " ")).join(" + ");
}

function adminLayout({ storeName, active, body, flash }) {
  const navItem = (path, label) => `<a href="${path}" class="${active === path ? "active" : ""}">${label}</a>`;
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin — ${storeName}</title>
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" href="/images/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="/style.css">
<link rel="stylesheet" href="/admin.css">
</head>
<body class="admin-body">
<div class="admin-shell">
  <aside class="admin-sidebar">
    <div class="logo" style="margin-bottom:30px;">
      <div class="logo-mark"></div>
      <div class="logo-text">${storeName}<span>Admin</span></div>
    </div>
    <nav class="admin-nav">
      ${navItem("/admin", "Dashboard")}
      ${navItem("/admin/products", "Products")}
      ${navItem("/admin/orders", "Orders")}
      ${navItem("/admin/unresolved", "Unresolved Orders")}
      ${navItem("/admin/subscriptions", "Subscriptions")}
      ${navItem("/admin/deliveries", "Deliveries")}
      ${navItem("/admin/players", "Players")}
      ${navItem("/admin/server", "Server Actions")}
      ${navItem("/admin/gift-cards", "Gift Cards")}
      ${navItem("/admin/discounts", "Discounts")}
      ${navItem("/admin/discord-perks", "Discord Perks")}
      ${navItem("/admin/pages", "Pages")}
      ${navItem("/admin/bans", "Bans")}
      ${navItem("/admin/tickets", "Support Tickets")}
    </nav>
    <a class="admin-nav-logout" href="/">&larr; Return to Store</a>
    <a class="admin-nav-logout" href="/admin/logout">Log out</a>
  </aside>
  <main class="admin-main">
    ${flash ? `<div class="notice">${esc(flash)}</div>` : ""}
    ${body}
  </main>
</div>
</body>
</html>`;
}

export function renderLogin({ storeName, error }) {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Login — ${storeName}</title>
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" href="/images/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="/style.css">
<link rel="stylesheet" href="/admin.css">
</head>
<body class="admin-body">
  <div class="login-box">
    <div class="logo" style="justify-content:center; margin-bottom:24px;">
      <div class="logo-mark"></div>
      <div class="logo-text">${storeName}<span>Admin</span></div>
    </div>
    ${error ? `<div class="notice" style="border-left-color:#e2231c;">${esc(error)}</div>` : ""}
    <form method="POST" action="/admin/login">
      <label>Password</label>
      <input type="password" name="password" autofocus required>
      <button class="btn block" type="submit" style="margin-top:16px;">Log In</button>
    </form>
  </div>
</body>
</html>`;
}

/** A stat card's number on its own can't tell you if the business is
 * growing — this renders the small "+18% vs last 30 days" (or a flat/down
 * variant) line underneath it, comparing to the prior 30-day window. */
function changeBadge(current, previous) {
  if (!previous) {
    // No prior-period data to compare against (new store, or first 30 days) —
    // showing "+∞%" or "0%" here would be misleading, so say nothing instead.
    return current > 0 ? `<div class="stat-change stat-change-flat">First 30 days of data</div>` : "";
  }
  const pct = ((current - previous) / previous) * 100;
  const rounded = Math.round(pct);
  const cls = rounded > 0 ? "stat-change-up" : rounded < 0 ? "stat-change-down" : "stat-change-flat";
  const arrow = rounded > 0 ? "▲" : rounded < 0 ? "▼" : "—";
  return `<div class="stat-change ${cls}">${arrow} ${Math.abs(rounded)}% vs prior 30 days</div>`;
}

/** Inline SVG bar chart of daily revenue — no chart library, consistent with
 * the rest of this store's zero-dependency approach. `series` is oldest-day-
 * first, one entry per calendar day (see fillDailySeries in db.js), so bars
 * are always evenly spaced even on days with no sales. */
function revenueChart(series) {
  const W = 720, H = 180, padL = 4, padR = 4, padTop = 14, padBottom = 28;
  const chartW = W - padL - padR;
  const chartH = H - padTop - padBottom;
  const maxCents = Math.max(1, ...series.map((d) => d.totalCents));
  const barGap = 4;
  const barW = series.length ? (chartW - barGap * (series.length - 1)) / series.length : 0;

  const bars = series
    .map((d, i) => {
      const x = padL + i * (barW + barGap);
      const barH = (d.totalCents / maxCents) * chartH;
      const y = padTop + (chartH - barH);
      const dateLabel = new Date(d.day + "T00:00:00Z").toLocaleDateString(undefined, { month: "short", day: "numeric" });
      return `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${barW.toFixed(1)}" height="${Math.max(barH, 1).toFixed(1)}" rx="2" fill="${d.totalCents > 0 ? "var(--red)" : "var(--bg-panel-2)"}"><title>${esc(dateLabel)}: ${money(d.totalCents)}</title></rect>`;
    })
    .join("");

  const firstLabel = series.length ? new Date(series[0].day + "T00:00:00Z").toLocaleDateString(undefined, { month: "short", day: "numeric" }) : "";
  const lastLabel = series.length ? new Date(series[series.length - 1].day + "T00:00:00Z").toLocaleDateString(undefined, { month: "short", day: "numeric" }) : "";

  return `
  <svg viewBox="0 0 ${W} ${H}" class="revenue-chart" role="img" aria-label="Daily revenue over the last ${series.length} days">
    ${bars}
    <text x="${padL}" y="${H - 8}" class="revenue-chart-label">${esc(firstLabel)}</text>
    <text x="${W - padR}" y="${H - 8}" class="revenue-chart-label" text-anchor="end">${esc(lastLabel)}</text>
  </svg>`;
}

export function renderDashboard({ storeName, stats, serverStatus, flash }) {
  const body = `
  <h1>Dashboard</h1>
  ${serverStatusPanel(serverStatus)}
  <div class="stat-grid">
    <div class="stat-card">
      <div class="stat-label">Total Revenue</div>
      <div class="stat-value">${money(stats.totalRevenueCents)}</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Revenue (30 days)</div>
      <div class="stat-value">${money(stats.revenue30dCents)}</div>
      ${changeBadge(stats.revenue30dCents, stats.revenuePrev30dCents)}
    </div>
    <div class="stat-card">
      <div class="stat-label">Orders (30 days)</div>
      <div class="stat-value">${stats.orderCount30d}</div>
      ${changeBadge(stats.orderCount30d, stats.orderCountPrev30d)}
    </div>
    <div class="stat-card">
      <div class="stat-label">Active Subscriptions</div>
      <div class="stat-value">${stats.activeSubCount}</div>
    </div>
  </div>

  ${stats.unresolvedOrders > 0 ? `<div class="notice" style="border-left-color:#e2231c;">${stats.unresolvedOrders} payment${stats.unresolvedOrders === 1 ? "" : "s"} succeeded but couldn't be matched to a SteamID — check <a href="/admin/unresolved">Unresolved Orders</a>.</div>` : ""}
  ${stats.failingDeliveries > 0 ? `<div class="notice" style="border-left-color:#e2231c;">${stats.failingDeliveries} command${stats.failingDeliveries === 1 ? "" : "s"} failed to deliver 5 times in a row — check <a href="/admin/deliveries">Deliveries</a>.</div>` : ""}
  ${stats.pendingDeliveries > 0 ? `<div class="notice">${stats.pendingDeliveries} command${stats.pendingDeliveries === 1 ? "" : "s"} queued for delivery.</div>` : ""}
  ${stats.pastDueSuspended > 0 ? `<div class="notice" style="border-left-color:#e2231c;">${stats.pastDueSuspended} subscription${stats.pastDueSuspended === 1 ? "" : "s"} past due with access suspended after repeated failed payments — check <a href="/admin/subscriptions">Subscriptions</a>.</div>` : ""}
  ${stats.pastDueInGracePeriod > 0 ? `<div class="notice">${stats.pastDueInGracePeriod} subscription${stats.pastDueInGracePeriod === 1 ? "" : "s"} past due — Stripe is still retrying, access not yet affected.</div>` : ""}

  <div class="admin-panel" style="margin-bottom:24px;">
    <h2>Revenue — last ${stats.dailyRevenue.length} days</h2>
    ${revenueChart(stats.dailyRevenue)}
  </div>

  <div class="admin-grid-2">
    <div class="admin-panel">
      <h2>Top Products</h2>
      <table class="admin-table">
        <thead><tr><th>Product</th><th>Sales</th><th>Revenue</th></tr></thead>
        <tbody>
          ${stats.topProducts.map((p) => `<tr><td>${esc(p.name)}</td><td>${p.sales}</td><td>${money(p.revenue)}</td></tr>`).join("") || `<tr><td colspan="3" class="muted">No sales yet</td></tr>`}
        </tbody>
      </table>
    </div>
    <div class="admin-panel">
      <h2>Recent Orders</h2>
      <table class="admin-table">
        <thead><tr><th>Product</th><th>SteamID</th><th>Amount</th><th>Date</th></tr></thead>
        <tbody>
          ${stats.recentOrders.map((o) => `<tr><td>${esc(o.product_name)}</td><td class="mono">${esc(o.steamid)}</td><td>${money(o.amount_cents)}</td><td>${fmtDate(o.created_at)}</td></tr>`).join("") || `<tr><td colspan="4" class="muted">No orders yet</td></tr>`}
        </tbody>
      </table>
    </div>
  </div>
  `;
  return adminLayout({ storeName, active: "/admin", body, flash });
}

/** Diagnostic panel showing exactly what the last server-status poll saw —
 * critical because the public homepage widget only ever shows a generic
 * "Status unavailable"/"Offline", with no way for anyone looking at it to
 * tell "cron isn't running", "this store uses polling-agent mode which
 * can't report status", "RCON_HOST isn't set", or "RCON is unreachable
 * even though the game server itself is up" (all four look IDENTICAL on
 * the public page) apart from each other. */
function serverStatusPanel(serverStatus) {
  if (!serverStatus) {
    return `<div class="notice">Server status hasn't been checked yet — migration_server_status.sql may not be applied. <form method="POST" action="/admin/server-status/check" style="display:inline;"><button class="link-btn" type="submit">Check Now</button></form></div>`;
  }

  const updatedAt = serverStatus.updated_at ? new Date(serverStatus.updated_at + "Z") : null;
  const ageMs = updatedAt ? Date.now() - updatedAt.getTime() : Infinity;
  const isStale = ageMs > 6 * 60 * 1000;

  return `
  <div class="admin-panel" style="margin-bottom:24px; display:block;">
    <h2>Server Status</h2>
    <div style="display:flex; align-items:center; gap:14px; flex-wrap:wrap;">
      <span class="badge ${serverStatus.online && !isStale ? "badge-active" : "badge-warning"}">${serverStatus.online && !isStale ? "Online" : isStale ? "Stale" : "Offline"}</span>
      ${serverStatus.online ? `<span>${serverStatus.players} / ${serverStatus.max_players} players${serverStatus.map ? ` · ${esc(serverStatus.map)}` : ""}</span>` : ""}
      <span class="muted" style="font-size:12px;">Last checked: ${updatedAt ? fmtDate(serverStatus.updated_at) : "never"}${isStale ? " (stale — if you're on polling-agent mode, your agent needs to POST to /api/agent/status; see DEPLOY.md)" : ""}</span>
      <form method="POST" action="/admin/server-status/check" style="margin-left:auto;">
        <button class="btn secondary" type="submit">Check Now</button>
      </form>
    </div>
    ${serverStatus.last_error ? `<div class="notice" style="margin-top:14px; margin-bottom:0;">Last error: <span class="mono">${esc(serverStatus.last_error)}</span></div>` : ""}
  </div>`;
}

export function renderProductList({ storeName, products, flash }) {
  const rows = products
    .map(
      (p) => `
    <tr>
      <td>${esc(p.name)}</td>
      <td class="mono">${esc(p.id)}</td>
      <td>${esc(CATEGORY_LABELS[p.category] || p.category)}</td>
      <td>${money(p.price_cents)}${p.is_subscription ? "/mo" : ""}</td>
      <td>${p.enabled ? '<span class="badge badge-active">Enabled</span>' : '<span class="badge badge-muted">Disabled</span>'}</td>
      <td class="admin-actions">
        <a href="/admin/products/${p.id}">Edit</a>
        <form method="POST" action="/admin/products/${p.id}/toggle" style="display:inline;">
          <button class="link-btn" type="submit">${p.enabled ? "Disable" : "Enable"}</button>
        </form>
        <form method="POST" action="/admin/products/${p.id}/delete" style="display:inline;" onsubmit="return confirm('Delete ${esc(p.name)}? This only works if it has no orders/subscriptions — otherwise disable it instead.');">
          <button class="link-btn link-btn-danger" type="submit">Delete</button>
        </form>
      </td>
    </tr>`
    )
    .join("");

  const body = `
  <div class="admin-header-row">
    <h1>Products</h1>
    <a class="btn" href="/admin/products/new">+ New Product</a>
  </div>
  <table class="admin-table">
    <thead><tr><th>Name</th><th>ID</th><th>Category</th><th>Price</th><th>Status</th><th></th></tr></thead>
    <tbody>${rows || `<tr><td colspan="6" class="muted">No products yet</td></tr>`}</tbody>
  </table>
  `;
  return adminLayout({ storeName, active: "/admin/products", body, flash });
}

export function renderProductForm({ storeName, product, error }) {
  const isEdit = !!product?.id;
  const v = (key, fallback = "") => esc(product?.[key] ?? fallback);

  const body = `
  <h1>${isEdit ? "Edit Product" : "New Product"}</h1>
  ${error ? `<div class="notice" style="border-left-color:#e2231c;">${esc(error)}</div>` : ""}
  <form method="POST" action="${isEdit ? `/admin/products/${product.id}` : "/admin/products"}" class="admin-form">
    ${!isEdit ? `
    <label>Product ID (slug — cannot be changed later)</label>
    <input type="text" name="id" pattern="[a-z0-9-]+" placeholder="e.g. raid-kit" required>
    ` : `<input type="hidden" name="id" value="${v("id")}">`}

    <label>Name</label>
    <input type="text" name="name" value="${v("name")}" required>

    <label>Description <span class="hint">— short blurb shown on the product card</span></label>
    <textarea name="description" rows="3">${v("description")}</textarea>

    <label>Full description <span class="hint">— shown on the product's own page. Leave blank to just reuse the short description.</span></label>
    <textarea name="full_description" rows="6">${v("full_description")}</textarea>

    <div class="form-row">
      <div>
        <label>Category</label>
        <select name="category">
          ${["kits", "packages", "items", "ranks"].map((c) => `<option value="${c}" ${product?.category === c ? "selected" : ""}>${esc(CATEGORY_LABELS[c])}</option>`).join("")}
        </select>
      </div>
      <div>
        <label>Price (USD)</label>
        <input type="number" step="0.01" min="0" name="price" value="${product ? (product.price_cents / 100).toFixed(2) : ""}" required>
      </div>
    </div>

    <label>Image URL</label>
    <input type="text" name="image_url" value="${v("image_url")}" placeholder="/images/raid-kit.png">

    <label>Bundle key <span class="hint">— give the one-time and subscription variant of the same product the same key (e.g. "vip-kit") so their product page offers both options together. Leave blank if this product doesn't have a paired variant.</span></label>
    <input type="text" name="bundle_key" value="${v("bundle_key")}" placeholder="vip-kit">

    <label class="checkbox-row">
      <input type="checkbox" name="is_subscription" ${product?.is_subscription ? "checked" : ""}>
      This is a monthly subscription, not a one-time purchase
    </label>

    <label>Grant command <span class="hint">— runs on purchase/renewal. Use {steamid} as a placeholder.</span></label>
    <input type="text" name="grant_command" value="${v("grant_command")}" placeholder="oxide.grant user {steamid} kits.vip" required>

    <label>Grant command 2 <span class="hint">— optional second command run right after the first (e.g. a paired kit). Leave blank if not needed.</span></label>
    <input type="text" name="grant_command_2" value="${v("grant_command_2")}" placeholder="kit mailgive {steamid} vip-tools">

    <label>Revoke command <span class="hint">— runs on expiry/cancellation/chargeback. Leave blank if not applicable.</span></label>
    <input type="text" name="revoke_command" value="${v("revoke_command")}" placeholder="oxide.revoke user {steamid} kits.vip">

    <label>Revoke command 2 <span class="hint">— optional second revoke command. Leave blank if not needed.</span></label>
    <input type="text" name="revoke_command_2" value="${v("revoke_command_2")}" placeholder="">

    <label>Sort order <span class="hint">— lower numbers show first within a category</span></label>
    <input type="number" name="sort_order" value="${product ? product.sort_order : 0}">

    <label class="checkbox-row">
      <input type="checkbox" name="enabled" ${product ? (product.enabled ? "checked" : "") : "checked"}>
      Visible on the store
    </label>

    <div style="margin-top:20px; display:flex; gap:12px;">
      <button class="btn" type="submit">${isEdit ? "Save Changes" : "Create Product"}</button>
      <a class="btn secondary" href="/admin/products">Cancel</a>
    </div>
  </form>
  `;
  return adminLayout({ storeName, active: "/admin/products", body });
}

export function renderOrders({ storeName, orders, page, hasMore, totalPages, total, flash }) {
  const rows = orders
    .map(
      (o) => `
    <tr>
      <td>${fmtDate(o.created_at)}</td>
      <td>${esc(o.product_name)}</td>
      <td class="mono">${esc(o.steamid)}</td>
      <td>${esc(o.customer_email || "—")}</td>
      <td>${money(o.amount_cents)}</td>
      <td>${esc(paymentMethodLabel(o.payment_method))}</td>
      <td><span class="badge ${o.status === "paid" ? "badge-active" : o.status === "chargeback" ? "badge-danger" : "badge-muted"}">${o.status}</span></td>
      <td>
        ${o.delivered ? '<span class="badge badge-active">Delivered</span>' : '<span class="badge badge-warning">Pending</span>'}
        ${!o.delivered
          ? `<form method="POST" action="/admin/orders/${o.id}/retry-delivery" style="display:inline;">
               <button class="link-btn" type="submit">Retry</button>
             </form>`
          : ""}
      </td>
    </tr>`
    )
    .join("");

  const body = `
  <div class="admin-header-row">
    <h1>Orders</h1>
    ${typeof total === "number" ? `<div class="muted">${total} total</div>` : ""}
  </div>
  <p class="muted" style="margin-top:-10px; margin-bottom:16px; font-size:13px;">"Pending" means the order was paid but its grant command hasn't been delivered in-game yet — click Retry once the underlying issue (usually RCON connectivity) is fixed. Check <a href="/admin/deliveries">Deliveries</a> for the failure reason first.</p>
  <table class="admin-table">
    <thead><tr><th>Date</th><th>Product</th><th>SteamID</th><th>Email</th><th>Amount</th><th>Paid With</th><th>Status</th><th>Delivery</th></tr></thead>
    <tbody>${rows || `<tr><td colspan="8" class="muted">No orders yet</td></tr>`}</tbody>
  </table>
  <div class="pagination">
    ${page > 0 ? `<a class="btn secondary" href="/admin/orders?page=${page - 1}">← Newer</a>` : ""}
    ${typeof totalPages === "number" ? `<span class="muted" style="align-self:center; font-family: var(--mono); font-size:12px;">Page ${page + 1} of ${totalPages}</span>` : ""}
    ${hasMore ? `<a class="btn secondary" href="/admin/orders?page=${page + 1}">Older →</a>` : ""}
  </div>
  `;
  return adminLayout({ storeName, active: "/admin/orders", body, flash });
}

export function renderSubscriptions({ storeName, subscriptions, page, hasMore }) {
  const rows = subscriptions
    .map(
      (s) => `
    <tr>
      <td>${fmtDate(s.created_at)}</td>
      <td>${esc(s.product_name)}</td>
      <td class="mono">${esc(s.steamid)}</td>
      <td>${esc(s.customer_email || "—")}</td>
      <td>
        <span class="badge ${s.status === "active" ? "badge-active" : s.status === "past_due" ? "badge-warning" : "badge-muted"}">${s.status}</span>
        ${s.access_suspended_at ? `<span class="badge badge-muted" title="Access revoked in-game after ${s.failed_payment_count} failed payment(s)">Suspended</span>` : s.failed_payment_count > 0 ? `<span class="hint">(${s.failed_payment_count} failed payment${s.failed_payment_count === 1 ? "" : "s"})</span>` : ""}
      </td>
      <td>${fmtDate(s.current_period_end)}</td>
    </tr>`
    )
    .join("");

  const body = `
  <h1>Subscriptions</h1>
  <table class="admin-table">
    <thead><tr><th>Started</th><th>Product</th><th>SteamID</th><th>Email</th><th>Status</th><th>Renews / Ended</th></tr></thead>
    <tbody>${rows || `<tr><td colspan="6" class="muted">No subscriptions yet</td></tr>`}</tbody>
  </table>
  <div class="pagination">
    ${page > 0 ? `<a class="btn secondary" href="/admin/subscriptions?page=${page - 1}">← Newer</a>` : ""}
    ${hasMore ? `<a class="btn secondary" href="/admin/subscriptions?page=${page + 1}">Older →</a>` : ""}
  </div>
  <p class="muted" style="margin-top:14px; font-size:13px;">Subscriptions are managed by customers/Stripe directly (cancel, payment method). This is a read-only view synced from Stripe webhooks.</p>
  `;
  return adminLayout({ storeName, active: "/admin/subscriptions", body });
}

export function renderDeliveries({ storeName, deliveries }) {
  const rows = deliveries
    .map(
      (d) => `
    <tr>
      <td>${fmtDate(d.created_at)}</td>
      <td class="mono">${esc(d.steamid)}</td>
      <td class="mono">${esc(d.command)}</td>
      <td>${esc(d.reason)}</td>
      <td>${d.delivered ? '<span class="badge badge-active">Delivered</span>' : d.attempts >= 5 ? '<span class="badge badge-danger">Failed</span>' : '<span class="badge badge-warning">Pending</span>'}</td>
      <td>${d.attempts}</td>
      <td class="mono muted" style="max-width:220px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${esc(d.last_error || "")}</td>
      <td>${!d.delivered && d.attempts >= 5 ? `<form method="POST" action="/admin/deliveries/${d.id}/retry"><button class="btn secondary" type="submit">Retry</button></form>` : ""}</td>
    </tr>`
    )
    .join("");

  const body = `
  <h1>Delivery Queue</h1>
  <p class="muted">Every RCON command sent to the game server — grants, revokes, renewals. Retries automatically every 2 minutes until delivered or 5 attempts fail.</p>
  <table class="admin-table">
    <thead><tr><th>Time</th><th>SteamID</th><th>Command</th><th>Reason</th><th>Status</th><th>Attempts</th><th>Last Error</th><th></th></tr></thead>
    <tbody>${rows || `<tr><td colspan="8" class="muted">Nothing queued yet</td></tr>`}</tbody>
  </table>
  `;
  return adminLayout({ storeName, active: "/admin/deliveries", body });
}

export function renderPlayerSearch({ storeName, flash, roster, search }) {
  const rows = (roster || [])
    .map((p) => {
      const lastSeen = p.lastSeen ? fmtDate(new Date(p.lastSeen * 1000).toISOString()) : "—";
      return `
      <tr>
        <td>${p.online ? `<span class="badge badge-active">Online</span>` : `<span class="badge">Offline</span>`}</td>
        <td><a href="/admin/players/${encodeURIComponent(p.steamid)}">${esc(p.name || p.steamid)}</a></td>
        <td class="muted">${esc(p.steamid)}</td>
        <td class="muted">${lastSeen}</td>
      </tr>`;
    })
    .join("");

  const rosterPanel =
    roster === null
      ? `<div class="notice" style="margin-top:20px;">Player roster ${search ? "search " : ""}isn't available right now — couldn't reach the server (direct RCON) or no roster has been pushed yet (polling-agent mode, needs the patched ApexAdminAudit.cs + ApexAgent.cs deployed). You can still look someone up by SteamID64 or name below.</div>`
      : `
      <div class="admin-panel" style="margin-top:20px;">
        <h3>Known players ${roster.length ? `<span class="muted" style="font-weight:normal;">(${roster.length}${roster.length === 500 ? "+" : ""})</span>` : ""}</h3>
        <p class="muted">Everyone ApexAdminAudit has seen connect — not just store customers. Click a name to open their card.</p>
        <table class="admin-table">
          <thead><tr><th></th><th>Name</th><th>SteamID</th><th>Last seen</th></tr></thead>
          <tbody>${rows || `<tr><td colspan="4" class="muted">${search ? "No matches." : "Nobody indexed yet."}</td></tr>`}</tbody>
        </table>
      </div>`;

  const body = `
  <h1>Players</h1>
  <p class="muted">Search by SteamID64, or by name if the player already has an ApexAdminAudit profile.</p>

  <div class="admin-panel" style="margin-top:20px; max-width:480px;">
    <form method="POST" action="/admin/players" class="admin-form">
      <div>
        <label>SteamID64 or name</label>
        <input type="text" name="query" placeholder="76561198... or a player name" autofocus>
      </div>
      <button class="btn" type="submit" style="margin-top:14px;">Look up</button>
    </form>
  </div>

  <form method="GET" action="/admin/players" class="admin-form" style="max-width:480px; margin-top:12px;">
    <div class="form-row" style="grid-template-columns: 1fr auto;">
      <input type="text" name="q" value="${esc(search || "")}" placeholder="Filter known players by name/SteamID">
      <button class="btn secondary" type="submit">Filter</button>
    </div>
  </form>

  ${rosterPanel}
  `;
  return adminLayout({ storeName, active: "/admin/players", body, flash });
}

// A single, reusable player card page shell - shown at /admin/players/:steamid
// and /admin/players/:steamid/permissions, so both pages agree on header,
// nav, and don't duplicate the profile-resolution boilerplate.
function playerCardBackLink(steamid) {
  return `<p class="muted"><a href="/admin/players/${encodeURIComponent(steamid)}">&larr; Back to player card</a></p>`;
}

export function renderPlayerPermissions({ storeName, steamid, permissions, flash }) {
  if (!permissions) {
    const body = `
    ${playerCardBackLink(steamid)}
    <h1>Permissions</h1>
    <div class="notice" style="margin-top:16px;">Couldn't load permissions for ${esc(steamid)}. In polling-agent mode this needs the patched ApexAdminAudit.cs + ApexAgent.cs deployed (query round-trip, takes up to ~12s) — in direct-RCON mode it should be near-instant, so a null result there usually means the server's unreachable right now.</div>
    `;
    return adminLayout({ storeName, active: "/admin/players", body, flash });
  }

  const groupRows = (permissions.groups || [])
    .map(
      (g) => `
      <tr>
        <td>${esc(g)}</td>
        <td>
          <form method="POST" action="/admin/players/${encodeURIComponent(steamid)}/action" style="display:inline;" onsubmit="return confirm('Remove ${esc(g).replace(/'/g, "")} from this player?');">
            <input type="hidden" name="actionType" value="perm_group_remove">
            <input type="hidden" name="returnTo" value="permissions">
            <input type="hidden" name="group" value="${esc(g)}">
            <button class="btn secondary danger" type="submit">Remove</button>
          </form>
        </td>
      </tr>`
    )
    .join("");

  const notInGroup = (permissions.allGroups || []).filter((g) => !(permissions.groups || []).includes(g));
  const addGroupOptions = notInGroup.map((g) => `<option value="${esc(g)}">${esc(g)}</option>`).join("");

  const permRows = (permissions.permissions || []).map((p) => `<li><code>${esc(p)}</code></li>`).join("");

  const body = `
  ${playerCardBackLink(steamid)}
  <h1>Permissions</h1>
  <p class="muted">${esc(steamid)}</p>

  <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px; margin-top:16px;">
    <div class="admin-panel">
      <h3>Groups</h3>
      <table class="admin-table">
        <thead><tr><th>Group</th><th></th></tr></thead>
        <tbody>${groupRows || `<tr><td colspan="2" class="muted">Not in any group.</td></tr>`}</tbody>
      </table>
      ${
        notInGroup.length
          ? `<form method="POST" action="/admin/players/${encodeURIComponent(steamid)}/action" class="admin-form" style="margin-top:14px;">
              <input type="hidden" name="actionType" value="perm_group_add">
              <input type="hidden" name="returnTo" value="permissions">
              <label>Add to group</label>
              <div class="form-row" style="grid-template-columns: 1fr auto;">
                <select name="group">${addGroupOptions}</select>
                <button class="btn secondary" type="submit">Add</button>
              </div>
            </form>`
          : ""
      }
    </div>
    <div class="admin-panel">
      <h3>Direct permissions</h3>
      <p class="muted">Granted straight to this player, outside any group.</p>
      <ul style="margin:0; padding-left:18px; max-height:400px; overflow:auto;">${permRows || `<li class="muted">None.</li>`}</ul>
    </div>
  </div>
  `;
  return adminLayout({ storeName, active: "/admin/players", body, flash });
}

function banBadge(bans) {
  if (bans === null) return `<span class="badge">Steam ban check unavailable (no API key configured)</span>`;
  if (!bans) return `<span class="badge">No Steam ban data</span>`;
  const flags = [];
  if (bans.vacBanned) flags.push(`<span class="badge badge-danger">VAC banned x${bans.numberOfVacBans} (${bans.daysSinceLastBan}d ago)</span>`);
  if (bans.numberOfGameBans > 0) flags.push(`<span class="badge badge-danger">${bans.numberOfGameBans} game ban(s)</span>`);
  if (bans.communityBanned) flags.push(`<span class="badge badge-warning">Community banned</span>`);
  if (bans.economyBan && bans.economyBan !== "none") flags.push(`<span class="badge badge-warning">Trade ban: ${esc(bans.economyBan)}</span>`);
  if (flags.length === 0) return `<span class="badge badge-active">Clean — no VAC/game/community bans</span>`;
  return flags.join(" ");
}

function riskBadge(profile) {
  if (!profile || !profile.found) return "";
  if (profile.trusted) return `<span class="badge badge-active">Trusted</span>`;
  if (profile.riskScore >= 70) return `<span class="badge badge-danger">Risk ${profile.riskScore}/100</span>`;
  if (profile.riskScore >= 35) return `<span class="badge badge-warning">Risk ${profile.riskScore}/100</span>`;
  return `<span class="badge">Risk ${profile.riskScore}/100</span>`;
}

// Player Card action panel — every single-player command lives here now,
// right next to the stats an admin just read to decide whether to use it.
// Grouped so the dangerous stuff (kick/ban) isn't sitting next to routine
// stuff (give points) with no visual distinction. Each mini-form posts
// straight to /admin/players/:steamid/action and redirects right back here.
function playerActionsPanel(steamid, { cases, items, kits } = {}) {
  const action = () => `/admin/players/${encodeURIComponent(steamid)}/action`;
  const hidden = (type) => `<input type="hidden" name="actionType" value="${type}">`;

  // Same degrade-gracefully pattern throughout: a live catalog gets a real
  // dropdown, a null/empty one falls back to a manual text field instead of
  // blocking the panel. See fetchCaseCatalog/fetchItemCatalog/fetchKitCatalog
  // in index.js for exactly when each one is null vs [].
  const caseField = cases && cases.length
    ? `<select name="caseId">${cases.map((c) => `<option value="${esc(c.id)}">${esc(c.displayName)} (${esc(c.id)})</option>`).join("")}</select>`
    : `<input type="text" name="caseId" placeholder="Case ID (catalog not loaded — enter manually)" required>`;

  const itemField = items && items.length
    ? `<select name="itemShortname">${items.map((i) => `<option value="${esc(i.shortname)}">${esc(i.displayName)} (${esc(i.shortname)})</option>`).join("")}</select>`
    : `<input type="text" name="itemShortname" placeholder="Item shortname, e.g. rifle.ak (catalog not loaded — enter manually)" required>`;

  const kitField = kits && kits.length
    ? `<select name="kitName">${kits.map((k) => `<option value="${esc(k)}">${esc(k)}</option>`).join("")}</select>`
    : `<input type="text" name="kitName" placeholder="Kit name (catalog not loaded — enter manually)" required>`;

  return `
    <div class="admin-panel">
      <h3>Actions</h3>

      <div style="display:grid; grid-template-columns: 1fr 1fr; gap:14px;">

        <form method="POST" action="${action()}" class="admin-form" style="margin:0;">
          ${hidden("give_points")}
          <label>Give points</label>
          <div class="form-row" style="grid-template-columns: 1fr auto;">
            <input type="number" name="amount" step="0.01" min="0.01" placeholder="Amount" required>
            <button class="btn secondary" type="submit">Give</button>
          </div>
        </form>

        <form method="POST" action="${action()}" class="admin-form" style="margin:0;">
          ${hidden("give_case")}
          <label>Give case</label>
          <div class="form-row" style="grid-template-columns: 1fr 70px auto;">
            ${caseField}
            <input type="number" name="amount" value="1" min="1" step="1">
            <button class="btn secondary" type="submit">Give</button>
          </div>
        </form>

        <form method="POST" action="${action()}" class="admin-form" style="margin:0;">
          ${hidden("give_item")}
          <label>Give item</label>
          <div class="form-row" style="grid-template-columns: 1fr 70px auto;">
            ${itemField}
            <input type="number" name="amount" value="1" min="1" step="1">
            <button class="btn secondary" type="submit">Give</button>
          </div>
        </form>

        <form method="POST" action="${action()}" class="admin-form" style="margin:0;">
          ${hidden("give_kit")}
          <label>Give kit <span class="muted" style="font-weight:normal;">(mailed, works offline)</span></label>
          <div class="form-row" style="grid-template-columns: 1fr auto;">
            ${kitField}
            <button class="btn secondary" type="submit">Give</button>
          </div>
        </form>

        <form method="POST" action="${action()}" class="admin-form" style="margin:0;">
          ${hidden("add_xp")}
          <label>Add rank XP</label>
          <div class="form-row" style="grid-template-columns: 1fr auto;">
            <input type="number" name="amount" step="1" min="1" placeholder="Amount" required>
            <button class="btn secondary" type="submit">Add</button>
          </div>
        </form>

        <form method="POST" action="${action()}" class="admin-form" style="margin:0;">
          ${hidden("whisper")}
          <label>Message player</label>
          <div class="form-row" style="grid-template-columns: 1fr auto;">
            <input type="text" name="text" placeholder="Message" required>
            <button class="btn secondary" type="submit">Send</button>
          </div>
        </form>

      </div>

      <hr style="border-color:var(--border); margin:16px 0;">

      <div style="display:flex; flex-wrap:wrap; gap:8px;">
        <form method="POST" action="${action()}" style="display:inline;">${hidden("freeze")}<button class="btn secondary" type="submit">Freeze / Unfreeze</button></form>
        <form method="POST" action="${action()}" style="display:inline;">${hidden("spectate")}<button class="btn secondary" type="submit">Spectate</button></form>
        <form method="POST" action="${action()}" style="display:inline;">${hidden("trust")}<button class="btn secondary" type="submit">Toggle Trusted</button></form>
        <form method="POST" action="${action()}" style="display:inline;">${hidden("vaccheck")}<button class="btn secondary" type="submit">Re-check VAC/Bans</button></form>
        <a class="btn secondary" href="/admin/players/${encodeURIComponent(steamid)}/permissions">View Permissions &rarr;</a>
      </div>

      <form method="POST" action="${action()}" class="admin-form" style="margin-top:14px;">
        ${hidden("note")}
        <label>Add audit note</label>
        <div class="form-row" style="grid-template-columns: 1fr auto;">
          <input type="text" name="text" placeholder="e.g. Warned for macro-suspicious fire rate" required>
          <button class="btn secondary" type="submit">Add</button>
        </div>
      </form>

      <hr style="border-color:var(--border); margin:16px 0;">

      <p class="muted" style="margin-bottom:8px;">Kick or ban — these end the player's session immediately.</p>
      <div style="display:flex; flex-wrap:wrap; gap:8px; align-items:center;">
        <form method="POST" action="${action()}" style="display:flex; gap:6px;" onsubmit="return confirm('Kick this player?');">
          ${hidden("kick")}
          <input type="text" name="reason" placeholder="Kick reason">
          <button class="btn secondary danger" type="submit">Kick</button>
        </form>
        <form method="POST" action="${action()}" style="display:flex; gap:6px;" onsubmit="return confirm('Permanently ban this player? This can be undone with Unban.');">
          ${hidden("ban")}
          <input type="text" name="reason" placeholder="Ban reason">
          <button class="btn secondary danger" type="submit">Ban</button>
        </form>
        <form method="POST" action="${action()}" style="display:inline;" onsubmit="return confirm('Lift this ban?');">
          ${hidden("unban")}
          <button class="btn secondary" type="submit">Unban</button>
        </form>
      </div>
    </div>
  `;
}

export function renderPlayerCard({ storeName, query, steamid, audit, points, cases, rankings, bans, account, steamProfile, items, kits, caseCatalog, evidence, flash }) {
  if (!steamid) {
    const body = `
    <h1>Players</h1>
    <p class="muted"><a href="/admin/players">&larr; Search again</a></p>
    <div class="admin-panel" style="margin-top:20px;">
      <p>No ApexAdminAudit profile found for "<strong>${esc(query)}</strong>", and it isn't a 17-digit SteamID64 either — so there's nothing to resolve it against.</p>
      <p class="muted">If they're online right now, try their exact in-game name, or look up their SteamID64 directly.</p>
    </div>
    `;
    return adminLayout({ storeName, active: "/admin/players", body, flash });
  }

  // Name/avatar resolution order: ApexAdminAudit's live in-game name first
  // (most current if they're online right now), then the store account
  // (if they've ever logged in with Steam here), then the public Steam
  // profile lookup — which works for ANY SteamID64 regardless of whether
  // they have ever signed into the store, so a player who's never touched
  // the website still shows a real name and avatar instead of a bare ID.
  const name = audit?.displayName || account?.player?.steam_name || steamProfile?.name || steamid;
  const avatar = account?.player?.steam_avatar || steamProfile?.avatar;
  const onlineDot = audit?.online ? `<span class="badge badge-active">Online</span>` : `<span class="badge">Offline</span>`;

  const profileUrl = steamProfile?.profileUrl || `https://steamcommunity.com/profiles/${steamid}/`;
  // steamLevel/accountCreated/rustPlaytimeHours only exist when
  // STEAM_API_KEY is configured (fetchSteamProfileFull) — the free XML
  // fallback (fetchSteamProfile) only ever has memberSince/location as
  // pre-formatted strings, no numeric fields. Handle both shapes.
  const hasFullProfile = steamProfile && (steamProfile.steamLevel != null || steamProfile.accountCreated);
  const steamMetaLine = steamProfile
    ? [
        hasFullProfile && steamProfile.accountCreated ? `Member since ${fmtDate(steamProfile.accountCreated)}` : (steamProfile.memberSince ? `Member since ${esc(steamProfile.memberSince)}` : null),
        hasFullProfile && steamProfile.steamLevel != null ? `Steam level ${steamProfile.steamLevel}` : null,
        hasFullProfile && steamProfile.rustPlaytimeHours != null ? `${steamProfile.rustPlaytimeHours.toLocaleString()}h in Rust${steamProfile.rustPlaytime2WeeksHours ? ` (${steamProfile.rustPlaytime2WeeksHours}h last 2wk)` : ""}` : null,
        hasFullProfile && steamProfile.personaState ? `Steam: ${esc(steamProfile.personaState)}` : null,
        (steamProfile.countryCode || steamProfile.location) ? esc(steamProfile.countryCode || steamProfile.location) : null,
        steamProfile.realName ? esc(steamProfile.realName) : null,
      ].filter(Boolean).join(" &nbsp;·&nbsp; ")
    : "";
  const header = `
    <div style="display:flex; align-items:center; gap:16px; margin-bottom:6px;">
      ${avatar ? `<img src="${esc(avatar)}" alt="" style="width:56px; height:56px; border-radius:8px;">` : ""}
      <div>
        <h1 style="margin:0;">${esc(name)}</h1>
        <p class="muted" style="margin:2px 0;">${esc(steamid)} &nbsp;·&nbsp; <a href="${esc(profileUrl)}" target="_blank" rel="noopener">Steam profile &rarr;</a></p>
        ${steamMetaLine ? `<p class="muted" style="margin:2px 0; font-size:12px;">${steamMetaLine}</p>` : `<p class="muted" style="margin:2px 0; font-size:12px;">Steam profile is private or unreachable — showing what's on record only.</p>`}
        ${!hasFullProfile ? `<p class="muted" style="margin:2px 0; font-size:11px;">Showing the free profile lookup — add <code>STEAM_API_KEY</code> for Steam level, real join date, and Rust playtime.</p>` : ""}
      </div>
    </div>
    <div style="margin-bottom:20px;">
      ${onlineDot} ${riskBadge(audit)} ${banBadge(bans)}
      ${audit?.found && audit.autoActionTier > 0 ? `<span class="badge badge-warning">Auto-action tier ${audit.autoActionTier}</span>` : ""}
    </div>
  `;

  // ---- Account / store panel ----
  const player = account?.player;
  const orders = account?.orders || [];
  const subs = account?.subs || [];
  const accountPanel = `
    <div class="admin-panel">
      <h3>Store Account</h3>
      ${
        player
          ? `<p>Discord: ${player.discord_username ? esc(player.discord_username) : "<span class=\"muted\">not linked</span>"}</p>
             <p>${orders.length} order(s), ${subs.filter((s) => s.status === "active").length} active subscription(s)</p>`
          : `<p class="muted">No store account on record for this SteamID.</p>`
      }
      ${orders.length ? `<table class="admin-table" style="margin-top:10px;">
        <tr><th>Date</th><th>Product</th><th>Total</th></tr>
        ${orders.slice(0, 5).map((o) => `<tr><td>${fmtDate(o.created_at)}</td><td>${esc(o.product_name || o.product_id)}</td><td>${money(o.total_cents)}</td></tr>`).join("")}
      </table>` : ""}
    </div>
  `;

  // ---- ApexAdminAudit panel ----
  const auditPanel = `
    <div class="admin-panel">
      <h3>Audit &amp; Risk</h3>
      ${
        audit?.found
          ? `<p>Suspicion: ${audit.suspicionScore}/100 &nbsp;|&nbsp; Combat suspicion: ${audit.combatSuspicion}/100 &nbsp;|&nbsp; Admin activity: ${audit.adminActivity}</p>
             <p>Kills: ${audit.kills} &nbsp;|&nbsp; Deaths: ${audit.deaths} &nbsp;|&nbsp; Headshots: ${audit.headshots} &nbsp;|&nbsp; Accuracy: ${audit.accuracy}% (${audit.combatHits}/${audit.shotsFired})</p>
             <p>Suspicious events flagged: ${audit.suspiciousEvents}</p>
             ${audit.notes?.length ? `<p><strong>Notes:</strong></p><ul>${audit.notes.map((n) => `<li>${esc(n.text)} <span class="muted">— ${esc(n.author)}, ${fmtDate(new Date(n.time * 1000).toISOString())}</span></li>`).join("")}</ul>` : ""}
             <p><strong>Recent history</strong></p>
             <table class="admin-table">
               <tr><th>Time</th><th>Event</th><th>As</th><th>Details</th></tr>
               ${(audit.recentEvents || []).slice(0, 15).map((e) => `
                 <tr>
                   <td>${fmtDate(new Date(e.time * 1000).toISOString())}</td>
                   <td>${esc(e.event)}</td>
                   <td>${e.role === "actor" ? "did to " + esc(e.otherName || "—") : "done by " + esc(e.otherName || "—")}</td>
                   <td>${esc(e.details || e.reason || e.command || "")}</td>
                 </tr>`).join("")}
             </table>`
          : `<p class="muted">No audit profile yet — this player hasn't triggered any tracked event.</p>`
      }
    </div>
  `;

  // ---- Rankings panel ----
  const rankingsPanel = `
    <div class="admin-panel">
      <h3>Rankings (Season)</h3>
      ${
        rankings?.found
          ? `<p>Rank: ${esc(rankings.rank)} &nbsp;|&nbsp; XP: ${rankings.xp.toLocaleString()} &nbsp;|&nbsp; Playtime: ${rankings.playtimeHours}h</p>
             <p>Kills: ${rankings.kills} &nbsp;|&nbsp; Deaths: ${rankings.deaths} &nbsp;|&nbsp; K/D: ${rankings.kd} &nbsp;|&nbsp; Headshots: ${rankings.headshots}</p>
             <p>Accuracy: ${rankings.accuracy}% (${rankings.hits}/${rankings.shots}) &nbsp;|&nbsp; Best streak: ${rankings.bestKillStreak}</p>
             <p>Raid damage: ${rankings.raidDamage.toLocaleString()} &nbsp;|&nbsp; TCs destroyed: ${rankings.raidsWon}</p>`
          : `<p class="muted">${rankings === null ? "Couldn't reach the server to fetch rankings." : "No rankings data for this player."}</p>`
      }
    </div>
  `;

  // ---- Economy panel (points + cases) ----
  const ownedCasesList = cases?.owned || [];
  const economyPanel = `
    <div class="admin-panel">
      <h3>Economy</h3>
      <p>Points balance: ${points?.found ? `${points.balance.toFixed ? points.balance.toFixed(2) : points.balance} ${esc(points.currencyName || "")}` : (points === null ? "couldn't reach server" : "0")}</p>
      ${
        ownedCasesList.length
          ? `<p><strong>Owned cases:</strong></p><ul>${ownedCasesList.map((c) => `<li>${esc(c.displayName)} × ${c.amount}</li>`).join("")}</ul>`
          : `<p class="muted">${cases === null ? "Couldn't reach the server to fetch case inventory." : "No cases owned."}</p>`
      }
    </div>
  `;

  const evidenceLines = (evidence?.lines || []).map((l) => `<div>${esc(l)}</div>`).join("");
  const evidencePanel = `
    <div class="admin-panel">
      <h3>Evidence Report</h3>
      ${
        evidence === null
          ? `<p class="muted">Not available right now — needs direct RCON (this isn't preloaded in polling-agent mode yet).</p>`
          : evidenceLines
            ? `<div style="font-family:monospace; font-size:12px; max-height:320px; overflow:auto; line-height:1.6;">${evidenceLines}</div>`
            : `<p class="muted">Nothing recorded for this player yet.</p>`
      }
    </div>`;

  const body = `
    <p class="muted"><a href="/admin/players">&larr; Search again</a></p>
    ${header}
    <div class="panel-grid">
      ${playerActionsPanel(steamid, { cases: caseCatalog, items, kits })}
      ${accountPanel}
      ${economyPanel}
      ${rankingsPanel}
      ${auditPanel}
      ${evidencePanel}
    </div>
    <p class="muted" style="margin-top:16px;">Need to push points/a case to everyone online at once, or run world/event controls (time of day, gather rates, cargo plane)? Use <a href="/admin/server">Server Actions</a>.</p>
  `;

  return adminLayout({ storeName, active: "/admin/players", body, flash });
}

// ============================================================
// Server Actions & Events — world/global commands with no single-player
// target. Deliberately separate from Player Actions/the player card:
// this page is "things done to the server itself" (time of day, gather
// rates, cargo plane events, broadcasts), not "things done to a player".
// ============================================================

export function renderServerActions({ storeName, serverStatus, wipeblockStatus, recentActivity, agentMode, consoleCommand, consoleOutput, flash }) {
  const statusPanel = serverStatus
    ? `<div class="admin-panel" style="margin-top:16px; margin-bottom:20px;">
        <p style="margin:0;">${serverStatus.online ? `<span class="badge badge-active">Online</span>` : `<span class="badge">Offline</span>`} ${esc(serverStatus.hostname || "")} &nbsp;\u00b7&nbsp; ${serverStatus.players ?? "?"}/${serverStatus.maxPlayers ?? "?"} players ${serverStatus.queued ? `(${serverStatus.queued} queued)` : ""} &nbsp;\u00b7&nbsp; ${esc(serverStatus.map || "")}</p>
        ${serverStatus.lastError ? `<p class="muted" style="margin:6px 0 0; font-size:12px;">Last note: ${esc(serverStatus.lastError)}</p>` : ""}
      </div>`
    : `<div class="notice" style="margin-top:16px; margin-bottom:20px;">No cached server status yet. ${agentMode ? "In polling-agent mode this fills in once ApexAgent.cs successfully POSTs to /api/agent/status - check it's installed, loaded, and pointed at the right Worker URL/secret." : "In direct-RCON mode this fills in on the next scheduled status check, or click Check Now on the Dashboard."} The controls below still queue normally either way.</div>`;

  // ---- Map & Seed ----
  const mapPanel = serverStatus?.seed
    ? `<div class="admin-panel">
        <h3>Map</h3>
        <p style="margin:4px 0;">${esc(serverStatus.map || "Procedural Map")} &nbsp;\u00b7&nbsp; Seed <code>${esc(serverStatus.seed)}</code>${serverStatus.size ? ` &nbsp;\u00b7&nbsp; Size ${esc(String(serverStatus.size))}` : ""}</p>
        ${serverStatus.size ? `<a class="btn secondary" href="https://rustmaps.com/map/${esc(String(serverStatus.size))}_${esc(String(serverStatus.seed))}" target="_blank" rel="noopener">View on RustMaps &rarr;</a>` : `<p class="muted">Map size wasn't in the last status check, so a direct RustMaps link can't be built automatically - seed alone: <code>${esc(serverStatus.seed)}</code></p>`}
      </div>`
    : `<div class="admin-panel">
        <h3>Map</h3>
        <p class="muted">No seed on record yet - this fills in once a status check returns it (some hosts omit Seed/Size from serverinfo; if it never appears, they may need to be enabled or read from your host's panel instead).</p>
      </div>`;

  // ---- Broadcast (moved from the old /admin/actions - "everyone online"
  // has no single player target, same as everything else on this page) ----
  const broadcastPanel = `
    <div class="admin-panel">
      <h3>Broadcast to Everyone Online</h3>
      <p class="muted">Reaches players connected right now only - it doesn't queue for anyone who joins later.</p>
      <form method="POST" action="/admin/server/action" class="admin-form" style="margin:0;">
        <input type="hidden" name="actionType" value="broadcast_points">
        <label>Give points to everyone</label>
        <div class="form-row" style="grid-template-columns: 1fr auto;">
          <input type="number" name="amount" step="0.01" min="0.01" placeholder="Amount" required>
          <button class="btn secondary" type="submit">Give</button>
        </div>
      </form>
      <form method="POST" action="/admin/server/action" class="admin-form" style="margin-top:10px;">
        <input type="hidden" name="actionType" value="broadcast_case">
        <label>Give a case to everyone</label>
        <div class="form-row" style="grid-template-columns: 1fr 70px auto;">
          <input type="text" name="caseId" placeholder="Case ID" required>
          <input type="number" name="amount" value="1" min="1" step="1">
          <button class="btn secondary" type="submit">Give</button>
        </div>
      </form>
      <form method="POST" action="/admin/server/action" class="admin-form" style="margin-top:10px;">
        <input type="hidden" name="actionType" value="announce">
        <label>Announce a message</label>
        <div class="form-row" style="grid-template-columns: 1fr auto;">
          <input type="text" name="message" placeholder="Message" required>
          <button class="btn secondary" type="submit">Send</button>
        </div>
      </form>
    </div>`;

  // ---- Wipe Block - now wired for real (WipeBlock.cs patched to accept
  // RCON) instead of the "in-game only" note it used to show. ----
  const wbToggle = (type, label, on) =>
    `<form method="POST" action="/admin/server/action" style="display:inline;"><input type="hidden" name="actionType" value="${type}"><button class="btn secondary" type="submit">${label}${on != null ? ` (currently ${on ? "ON" : "OFF"})` : ""}</button></form>`;

  const wipeblockPanel = `
    <div class="admin-panel">
      <h3>Wipe Block</h3>
      ${
        wipeblockStatus
          ? `<p style="margin:4px 0 14px;">${wipeblockStatus.active ? `<span class="badge badge-active">Active</span> ${Math.round(wipeblockStatus.remainingSeconds / 3600)}h remaining` : `<span class="badge">Not active</span>`} &nbsp;\u00b7&nbsp; Mode: ${esc(wipeblockStatus.blockMode)} &nbsp;\u00b7&nbsp; Duration: ${wipeblockStatus.durationHours}h</p>`
          : `<p class="muted" style="margin-bottom:14px;">Status not available right now - needs the patched WipeBlock.cs deployed and reachable.</p>`
      }
      <div style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:12px;">
        ${wbToggle("wipeblock_toggle_enabled", "Auto-arm on wipe", wipeblockStatus?.autoArmOnWipe)}
        ${wbToggle("wipeblock_toggle_mode", "Block mode (All\u2194Explosive)", null)}
        ${wbToggle("wipeblock_toggle_admins", "Ignore admins", wipeblockStatus?.ignoreAdmins)}
        ${wbToggle("wipeblock_toggle_broadcast", "Broadcast reminders", wipeblockStatus?.broadcast)}
        ${wbToggle("wipeblock_start_now", "Start Now", null)}
        ${wbToggle("wipeblock_clear", "Clear", null)}
      </div>
      <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px;">
        <form method="POST" action="/admin/server/action" class="admin-form" style="margin:0;">
          <input type="hidden" name="actionType" value="wipeblock_set_duration">
          <label>Set duration (hours)</label>
          <div class="form-row" style="grid-template-columns: 1fr auto;">
            <input type="number" name="hours" min="0.1" step="0.1" required>
            <button class="btn secondary" type="submit">Set</button>
          </div>
        </form>
        <form method="POST" action="/admin/server/action" class="admin-form" style="margin:0;">
          <input type="hidden" name="actionType" value="wipeblock_add_hours">
          <label>Add hours</label>
          <div class="form-row" style="grid-template-columns: 1fr auto;">
            <input type="number" name="hours" min="0.1" step="0.1" required>
            <button class="btn secondary" type="submit">Add</button>
          </div>
        </form>
      </div>
    </div>`;

  // ---- Mini console - direct-RCON only. In polling mode a command still
  // queues and runs on the next poll, but there's no round trip today to
  // bring the output back, so we're honest about that instead of faking a
  // response. ----
  const consolePanel = agentMode
    ? `<div class="admin-panel">
        <h3>Console</h3>
        <p class="muted">Not available in polling-agent mode yet - there's no response round trip for arbitrary commands today (only specific read endpoints like the player roster and permissions have one). You can still fire one-way commands via the forms elsewhere on this page; they queue and run on the next poll with no visible output here.</p>
      </div>`
    : `<div class="admin-panel">
        <h3>Console</h3>
        <p class="muted">Runs any RCON command directly against the server, live - same idea as rcon.io's console.</p>
        <form method="POST" action="/admin/console/exec" class="admin-form" style="margin:0;">
          <div class="form-row" style="grid-template-columns: 1fr auto;">
            <input type="text" name="command" value="${esc(consoleCommand || "")}" placeholder="e.g. playerlist, serverinfo, apexaudit.recent 10" autocomplete="off">
            <button class="btn secondary" type="submit">Run</button>
          </div>
        </form>
        ${
          consoleOutput != null
            ? `<div style="margin-top:12px;">
                <p class="muted" style="margin:0 0 4px; font-size:12px;">&gt; ${esc(consoleCommand || "")}</p>
                <div class="console-output">${esc(consoleOutput)}</div>
              </div>`
            : `<p class="muted" style="margin-top:12px;">Output from your last command appears here after you run one.</p>`
        }
      </div>`;

  // ---- Recent Activity / chat feed - flagged lines get a highlighted
  // badge for a human to review. Nothing here auto-punishes anyone. ----
  const activityRows = (recentActivity || [])
    .map((e) => {
      const time = e.time ? fmtDate(new Date(e.time * 1000).toISOString()) : "";
      return `<tr${e.flagged ? ` class="flagged"` : ""}>
        <td class="muted">${esc(time)}</td>
        <td>${esc(e.event || "")}</td>
        <td>${esc(e.actorName || e.actorId || "")}</td>
        <td>${esc(e.details || "")} ${e.flagged ? `<span class="badge badge-danger">flagged</span>` : ""}</td>
      </tr>`;
    })
    .join("");

  const activityPanel = `
    <div class="admin-panel" style="grid-column: 1 / -1;">
      <h3>Recent Activity</h3>
      ${
        recentActivity === null
          ? `<p class="muted">Not available right now - needs direct RCON (this isn't preloaded in polling-agent mode yet).</p>`
          : `<p class="muted">Server-wide feed from ApexAdminAudit, most recent first. Rows in red matched a conservative flagged-word list - review only, nothing is auto-actioned.</p>
             <table class="admin-table">
               <thead><tr><th>Time</th><th>Event</th><th>Player</th><th>Details</th></tr></thead>
               <tbody>${activityRows || `<tr><td colspan="4" class="muted">Nothing recent.</td></tr>`}</tbody>
             </table>`
      }
    </div>`;

  const body = `
  <h1>Server Actions</h1>
  <p class="muted">World and event controls \u2014 these apply server-wide, not to a specific player. For per-player actions (give/kick/ban/freeze), use a player's card under <a href="/admin/players">Players</a>.</p>

  ${statusPanel}

  <div class="panel-grid">

    <div class="admin-panel">
      <h3>Time of Day</h3>
      <div style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:14px;">
        <form method="POST" action="/admin/server/action" style="display:inline;"><input type="hidden" name="actionType" value="tod_skipday"><button class="btn secondary" type="submit">Skip to Day</button></form>
        <form method="POST" action="/admin/server/action" style="display:inline;"><input type="hidden" name="actionType" value="tod_skipnight"><button class="btn secondary" type="submit">Skip to Night</button></form>
        <form method="POST" action="/admin/server/action" style="display:inline;"><input type="hidden" name="actionType" value="tod_freezetime"><button class="btn secondary" type="submit">Toggle Freeze Time</button></form>
      </div>
      <form method="POST" action="/admin/server/action" class="admin-form" style="margin:0;">
        <input type="hidden" name="actionType" value="tod_daylength">
        <label>Day length (hours)</label>
        <div class="form-row" style="grid-template-columns: 1fr auto;">
          <input type="number" name="hours" min="0.1" step="0.1" placeholder="e.g. 3" required>
          <button class="btn secondary" type="submit">Set</button>
        </div>
      </form>
      <form method="POST" action="/admin/server/action" class="admin-form" style="margin-top:10px;">
        <input type="hidden" name="actionType" value="tod_nightlength">
        <label>Night length (hours)</label>
        <div class="form-row" style="grid-template-columns: 1fr auto;">
          <input type="number" name="hours" min="0.1" step="0.1" placeholder="e.g. 1" required>
          <button class="btn secondary" type="submit">Set</button>
        </div>
      </form>
    </div>

    <div class="admin-panel">
      <h3>Cargo Plane Crash Event</h3>
      <p class="muted">Forces the CargoPlaneCrash event to run (or stops one already in progress). Moved here from the old Player Actions page - it's a server-wide event, not a per-player one.</p>
      <div style="display:flex; flex-wrap:wrap; gap:8px;">
        <form method="POST" action="/admin/server/action" style="display:inline;"><input type="hidden" name="actionType" value="cargo_force"><button class="btn secondary" type="submit">Force Now</button></form>
        <form method="POST" action="/admin/server/action" style="display:inline;"><input type="hidden" name="actionType" value="cargo_stop"><button class="btn secondary" type="submit">Stop</button></form>
      </div>
    </div>

    <div class="admin-panel">
      <h3>Gather Rate</h3>
      <p class="muted">Sets a gather multiplier for one resource, or <code>*</code> for all. "remove" clears an override instead of setting a number.</p>
      <form method="POST" action="/admin/server/action" class="admin-form" style="margin:0;">
        <input type="hidden" name="actionType" value="gather_rate">
        <div class="form-row" style="grid-template-columns: 1fr 1fr;">
          <div>
            <label>Source</label>
            <select name="source">
              <option value="dispenser">Dispenser (trees/ore/etc.)</option>
              <option value="pickup">Pickup</option>
              <option value="quarry">Quarry</option>
              <option value="excavator">Excavator</option>
              <option value="survey">Survey Charge</option>
            </select>
          </div>
          <div>
            <label>Resource</label>
            <input type="text" name="resource" value="*" placeholder="* for all">
          </div>
        </div>
        <div style="margin-top:10px;">
          <label>Multiplier (or "remove")</label>
          <div class="form-row" style="grid-template-columns: 1fr auto;">
            <input type="text" name="multiplier" placeholder="e.g. 2 or remove" required>
            <button class="btn secondary" type="submit">Apply</button>
          </div>
        </div>
      </form>
    </div>

    ${broadcastPanel}

    <div class="admin-panel">
      <h3>Automated Events</h3>
      <p class="muted">Runs against AutomatedEvents' configured chat commands (default names shown \u2014 yours may differ if you've customized <code>Chat.RunEventCommand</code> etc. in its config).</p>
      <form method="POST" action="/admin/server/action" class="admin-form" style="margin:0;">
        <input type="hidden" name="actionType" value="run_event">
        <label>Force-run event</label>
        <div class="form-row" style="grid-template-columns: 1fr auto;">
          <select name="eventName">
            <option value="bradley">Bradley APC</option>
            <option value="helicopter">Patrol Helicopter</option>
            <option value="plane">Cargo Plane</option>
            <option value="ship">Cargo Ship</option>
            <option value="chinook">Chinook</option>
            <option value="xmas">Christmas</option>
            <option value="easter">Easter</option>
            <option value="halloween">Halloween</option>
          </select>
          <button class="btn secondary" type="submit">Run</button>
        </div>
      </form>
      <div style="display:flex; gap:8px; margin-top:10px;">
        <form method="POST" action="/admin/server/action" style="display:inline;"><input type="hidden" name="actionType" value="next_event"><button class="btn secondary" type="submit">Show Next Scheduled</button></form>
        <form method="POST" action="/admin/server/action" style="display:inline;"><input type="hidden" name="actionType" value="kill_event"><button class="btn secondary" type="submit">Kill Running Event</button></form>
      </div>
    </div>

    ${mapPanel}

    ${wipeblockPanel}

    ${consolePanel}

    <div class="admin-panel">
      <h3>Discord Report</h3>
      <p class="muted">Sends ApexAdminAudit's daily summary to Discord right now instead of waiting for its scheduled time.</p>
      <form method="POST" action="/admin/server/action" style="display:inline;"><input type="hidden" name="actionType" value="discord_report"><button class="btn secondary" type="submit">Send Now</button></form>
    </div>

    ${activityPanel}

  </div>
  `;
  return adminLayout({ storeName, active: "/admin/server", body, flash });
}


export function renderGiftCardsAdmin({ storeName, giftCards, flash }) {
  const rows = giftCards
    .map(
      (g) => `
    <tr>
      <td class="mono">${esc(g.code)}</td>
      <td>${money(g.initial_cents)}</td>
      <td>${money(g.balance_cents)}</td>
      <td>${g.source === "admin" ? '<span class="badge badge-muted">Admin</span>' : '<span class="badge badge-active">Purchased</span>'}</td>
      <td>${esc(g.customer_email || "—")}</td>
      <td>${g.enabled ? '<span class="badge badge-active">Enabled</span>' : '<span class="badge badge-muted">Disabled</span>'}</td>
      <td>${fmtDate(g.created_at)}</td>
      <td class="admin-actions">
        <form method="POST" action="/admin/gift-cards/${g.id}/toggle" style="display:inline;">
          <button class="link-btn" type="submit">${g.enabled ? "Disable" : "Enable"}</button>
        </form>
      </td>
    </tr>`
    )
    .join("");

  const totalOutstanding = giftCards.filter((g) => g.enabled).reduce((sum, g) => sum + g.balance_cents, 0);

  const body = `
  <div class="admin-header-row">
    <h1>Gift Cards</h1>
  </div>

  <div class="stat-grid" style="margin-bottom:24px;">
    <div class="stat-card">
      <div class="stat-label">Live Gift Cards</div>
      <div class="stat-value">${giftCards.filter((g) => g.enabled).length}</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Total Outstanding Balance</div>
      <div class="stat-value">${money(totalOutstanding)}</div>
    </div>
  </div>

  <div class="admin-panel" style="margin-bottom:24px;">
    <h2>Create a Gift Card</h2>
    <form method="POST" action="/admin/gift-cards" class="admin-form">
      <div class="form-row">
        <div>
          <label>Amount</label>
          <input type="number" step="0.01" min="0.01" name="amount" required>
        </div>
        <div>
          <label>Recipient email <span class="hint">— optional, just for your records</span></label>
          <input type="email" name="email">
        </div>
      </div>
      <button class="btn" type="submit" style="margin-top:14px;">Create Gift Card</button>
    </form>
  </div>

  <table class="admin-table">
    <thead><tr><th>Code</th><th>Initial</th><th>Balance</th><th>Source</th><th>Email</th><th>Status</th><th>Created</th><th></th></tr></thead>
    <tbody>${rows || `<tr><td colspan="8" class="muted">No gift cards yet</td></tr>`}</tbody>
  </table>
  `;
  return adminLayout({ storeName, active: "/admin/gift-cards", body, flash });
}

// ============================================================
// Discount codes
// ============================================================

export function renderDiscountsAdmin({ storeName, discountCodes, flash }) {
  const rows = discountCodes
    .map((d) => {
      const valueLabel = d.type === "percent" ? `${d.value}%` : money(d.value);
      const usageLabel = d.max_uses != null ? `${d.uses_count} / ${d.max_uses}` : `${d.uses_count} (unlimited)`;
      const isExpired = d.expires_at && new Date(d.expires_at) < new Date();
      const statusBadge = !d.enabled
        ? '<span class="badge badge-muted">Disabled</span>'
        : isExpired
          ? '<span class="badge badge-warning">Expired</span>'
          : '<span class="badge badge-active">Active</span>';
      return `
    <tr>
      <td class="mono">${esc(d.code)}</td>
      <td>${d.type === "percent" ? "Percent" : "Fixed"}</td>
      <td>${valueLabel}</td>
      <td>${usageLabel}</td>
      <td>${d.expires_at ? fmtDate(d.expires_at) : "Never"}</td>
      <td>${statusBadge}</td>
      <td class="admin-actions">
        <form method="POST" action="/admin/discounts/${d.id}/toggle" style="display:inline;">
          <button class="link-btn" type="submit">${d.enabled ? "Disable" : "Enable"}</button>
        </form>
      </td>
    </tr>`;
    })
    .join("");

  const body = `
  <div class="admin-header-row">
    <h1>Discount Codes</h1>
  </div>

  <div class="admin-panel" style="margin-bottom:24px;">
    <h2>Create a Discount Code</h2>
    <p class="muted" style="margin-top:-8px; margin-bottom:14px; font-size:13px;">Applies at cart checkout (kits/packages/items), alongside or instead of a gift card. Not supported on subscription checkout.</p>
    <form method="POST" action="/admin/discounts" class="admin-form">
      <div class="form-row">
        <div>
          <label>Code</label>
          <input type="text" name="code" placeholder="WIPE10" required style="text-transform:uppercase;">
        </div>
        <div>
          <label>Type</label>
          <select name="type">
            <option value="percent">Percent off</option>
            <option value="fixed">Fixed amount off</option>
          </select>
        </div>
        <div>
          <label>Value <span class="hint">— percent (1–100) or amount in £</span></label>
          <input type="number" step="0.01" min="0.01" name="value" required>
        </div>
      </div>
      <div class="form-row">
        <div>
          <label>Max uses <span class="hint">— optional, leave blank for unlimited</span></label>
          <input type="number" min="1" name="max_uses">
        </div>
        <div>
          <label>Expires <span class="hint">— optional</span></label>
          <input type="date" name="expires_at">
        </div>
      </div>
      <button class="btn" type="submit" style="margin-top:14px;">Create Code</button>
    </form>
  </div>

  <table class="admin-table">
    <thead><tr><th>Code</th><th>Type</th><th>Value</th><th>Uses</th><th>Expires</th><th>Status</th><th></th></tr></thead>
    <tbody>${rows || `<tr><td colspan="7" class="muted">No discount codes yet</td></tr>`}</tbody>
  </table>
  `;
  return adminLayout({ storeName, active: "/admin/discounts", body, flash });
}

// ============================================================
// Discord role perks (role -> in-game grant/revoke command)
// ============================================================

export function renderDiscordPerksAdmin({ storeName, perks, discordConfigured, flash }) {
  const rows = perks
    .map(
      (p) => `
    <tr>
      <td>${esc(p.label)}</td>
      <td class="mono">${esc(p.discord_role_id)}</td>
      <td class="mono">${esc(p.grant_command)}</td>
      <td class="mono">${p.revoke_command ? esc(p.revoke_command) : "—"}</td>
      <td>
        <form method="POST" action="/admin/discord-perks/${p.id}/discount" style="display:flex; gap:6px; align-items:center;">
          <input type="number" name="discount_percent" min="1" max="100" value="${p.discount_percent || ""}" placeholder="—" style="width:60px;">
          <button class="link-btn" type="submit">Save</button>
        </form>
      </td>
      <td>${p.enabled ? '<span class="badge badge-active">Enabled</span>' : '<span class="badge badge-muted">Disabled</span>'}</td>
      <td class="admin-actions">
        <form method="POST" action="/admin/discord-perks/${p.id}/toggle" style="display:inline;">
          <button class="link-btn" type="submit">${p.enabled ? "Disable" : "Enable"}</button>
        </form>
        <form method="POST" action="/admin/discord-perks/${p.id}/delete" style="display:inline;" onsubmit="return confirm('Delete this perk mapping? Players who already have it won\\'t be revoked automatically.');">
          <button class="link-btn" type="submit">Delete</button>
        </form>
      </td>
    </tr>`
    )
    .join("");

  const body = `
  <div class="admin-header-row">
    <h1>Discord Perks</h1>
  </div>
  <p class="muted" style="margin-top:-10px; margin-bottom:20px;">
    Maps a Discord role to an in-game grant/revoke command. Checked automatically whenever a player links Discord, and re-checked on a schedule so a lapsed Boost (or a role removed in Discord) revokes the perk without them doing anything.
  </p>

  ${
    !discordConfigured
      ? `<div class="notice" style="margin-bottom:20px;">Discord isn't fully configured yet — set DISCORD_CLIENT_ID/DISCORD_GUILD_ID in wrangler.toml and the DISCORD_CLIENT_SECRET/DISCORD_BOT_TOKEN secrets. See the setup notes at the top of src/discord-auth.js.</div>`
      : ""
  }

  <div class="admin-panel" style="margin-bottom:24px;">
    <h2>Add a Perk</h2>
    <form method="POST" action="/admin/discord-perks" class="admin-form">
      <div class="form-row">
        <div>
          <label>Label <span class="hint">— shown in this list only</span></label>
          <input type="text" name="label" placeholder="Server Booster" required>
        </div>
        <div>
          <label>Discord Role ID <span class="hint">— enable Developer Mode, right-click the role -> Copy Role ID</span></label>
          <input type="text" name="discord_role_id" placeholder="123456789012345678" required pattern="[0-9]{15,25}">
        </div>
      </div>
      <div class="form-row">
        <div>
          <label>Grant command <span class="hint">— use {steamid}</span></label>
          <input type="text" name="grant_command" placeholder="oxide.grant user {steamid} kits.vip" required>
        </div>
        <div>
          <label>Revoke command <span class="hint">— optional, runs when the role is lost</span></label>
          <input type="text" name="revoke_command" placeholder="oxide.revoke user {steamid} kits.vip">
        </div>
      </div>
      <div class="form-row">
        <div>
          <label>Store discount % <span class="hint">— optional, auto-applied at cart checkout for players who hold this role. Editable anytime.</span></label>
          <input type="number" name="discount_percent" min="1" max="100" placeholder="5">
        </div>
      </div>
      <button class="btn" type="submit" style="margin-top:14px;">Add Perk</button>
    </form>
  </div>

  <table class="admin-table">
    <thead><tr><th>Label</th><th>Role ID</th><th>Grant</th><th>Revoke</th><th>Discount</th><th>Status</th><th></th></tr></thead>
    <tbody>${rows || `<tr><td colspan="7" class="muted">No Discord perks configured yet</td></tr>`}</tbody>
  </table>
  `;
  return adminLayout({ storeName, active: "/admin/discord-perks", body, flash });
}

// ============================================================
// Site pages (Rules, Wipe Schedule)
// ============================================================

export function renderPagesAdmin({ storeName, pages, flash }) {
  const rows = pages
    .map(
      (p) => `
    <tr>
      <td>${esc(p.title)}</td>
      <td class="mono">/${esc(p.slug)}</td>
      <td>${fmtDate(p.updated_at)}</td>
      <td class="admin-actions"><a href="/admin/pages/${esc(p.slug)}">Edit</a></td>
    </tr>`
    )
    .join("");

  const body = `
  <div class="admin-header-row">
    <h1>Pages</h1>
  </div>
  <p class="muted" style="margin-top:-10px; margin-bottom:20px;">Content shown on the public Rules and Wipe Schedule pages — edit here any time, no deploy needed.</p>
  <table class="admin-table">
    <thead><tr><th>Title</th><th>URL</th><th>Last Updated</th><th></th></tr></thead>
    <tbody>${rows || `<tr><td colspan="4" class="muted">No pages found — run migration_site_pages.sql</td></tr>`}</tbody>
  </table>
  `;
  return adminLayout({ storeName, active: "/admin/pages", body, flash });
}

export function renderPageForm({ storeName, page, flash }) {
  const body = `
  <div class="admin-header-row">
    <h1>Edit ${esc(page.title)}</h1>
    <a class="btn secondary" href="/${esc(page.slug)}" target="_blank" rel="noopener noreferrer">View Live →</a>
  </div>

  <form method="POST" action="/admin/pages/${esc(page.slug)}" class="admin-form">
    <label>Title</label>
    <input type="text" name="title" value="${esc(page.title)}" required>

    <label style="margin-top:14px;">Content <span class="hint">— raw HTML, shown exactly as written</span></label>
    <textarea name="content" rows="16" style="font-family:var(--mono,monospace); font-size:13px;">${esc(page.content)}</textarea>

    <div style="margin-top:16px; display:flex; gap:10px;">
      <button class="btn" type="submit">Save</button>
      <a class="btn secondary" href="/admin/pages">Cancel</a>
    </div>
  </form>
  `;
  return adminLayout({ storeName, active: "/admin/pages", body, flash });
}

// ============================================================
// Chargeback bans
// ============================================================

export function renderBansAdmin({ storeName, bans, flash }) {
  const rows = bans
    .map((b) => {
      const statusBadge = b.lifted_at
        ? '<span class="badge badge-muted">Lifted</span>'
        : '<span class="badge badge-warning">Banned</span>';
      return `
    <tr>
      <td class="mono">${esc(b.steamid)}</td>
      <td>${b.order_id ? `#${b.order_id}` : "—"}${b.amount_cents ? ` (${money(b.amount_cents)})` : ""}</td>
      <td>${fmtDate(b.banned_at)}</td>
      <td>${statusBadge}</td>
      <td>${b.lifted_at ? `${fmtDate(b.lifted_at)}${b.lifted_note ? ` — ${esc(b.lifted_note)}` : ""}` : "—"}</td>
      <td class="admin-actions">
        ${
          b.lifted_at
            ? ""
            : `<form method="POST" action="/admin/bans/${b.id}/lift" style="display:flex; gap:6px;">
                 <input type="text" name="note" placeholder="Reason for lifting (optional)" style="font-size:12px; padding:6px 8px;">
                 <button class="link-btn" type="submit">Lift ban</button>
               </form>`
        }
      </td>
    </tr>`;
    })
    .join("");

  return adminLayout({
    storeName,
    active: "/admin/bans",
    flash,
    body: `
  <div class="admin-header-row">
    <h1>Chargeback Bans</h1>
  </div>
  <p class="muted" style="margin-top:-10px; margin-bottom:20px;">
    Issued automatically when a payment is disputed (see onChargeback / CHARGEBACK_AUTO_BAN in wrangler.toml). The unban command runs through the same delivery queue as everything else — check Admin &gt; Deliveries if a lift doesn't seem to take effect in-game.
  </p>
  <table class="admin-table">
    <thead><tr><th>SteamID</th><th>Order</th><th>Banned</th><th>Status</th><th>Lifted</th><th></th></tr></thead>
    <tbody>${rows || `<tr><td colspan="6" class="muted">No chargeback bans yet</td></tr>`}</tbody>
  </table>
  `,
  });
}

// ============================================================
// Unresolved orders — payment succeeded, no valid SteamID captured
// ============================================================

export function renderUnresolvedOrders({ storeName, unresolved, flash }) {
  const rows = unresolved
    .map((u) => {
      const cartSummary = (() => {
        if (u.mode === "subscription") return `Subscription: ${esc(u.product_id || "unknown")}`;
        try {
          const cart = JSON.parse(u.cart_json || "[]");
          return cart.map((i) => `${esc(i.productId)} ×${i.quantity}`).join(", ") || "—";
        } catch {
          return "—";
        }
      })();
      return `
    <tr>
      <td>${fmtDate(u.created_at)}</td>
      <td class="mono" title="${esc(u.stripe_session_id)}">${esc(u.stripe_session_id.slice(0, 20))}…</td>
      <td>${cartSummary}</td>
      <td>${esc(u.customer_email || "—")}</td>
      <td>${u.amount_total_cents != null ? money(u.amount_total_cents) : "—"}</td>
      <td><span class="badge badge-warning">${u.reason === "missing_steamid" ? "No SteamID" : "Invalid SteamID"}</span>${u.attempted_steamid ? `<div class="hint mono">got: "${esc(u.attempted_steamid)}"</div>` : ""}</td>
      <td class="admin-actions">
        <form method="POST" action="/admin/unresolved/${u.id}/resolve" style="display:flex; gap:6px;">
          <input type="text" name="steamid" placeholder="17-digit SteamID64" pattern="[0-9]{17}" maxlength="17" style="font-size:12px; padding:6px 8px; width:150px;" required>
          <button class="link-btn" type="submit">Resolve &amp; Deliver</button>
        </form>
      </td>
    </tr>`;
    })
    .join("");

  return adminLayout({
    storeName,
    active: "/admin/unresolved",
    flash,
    body: `
  <div class="admin-header-row">
    <h1>Unresolved Orders</h1>
  </div>
  <p class="muted" style="margin-top:-10px; margin-bottom:20px; font-size:13px;">
    Payment succeeded in Stripe, but no valid SteamID64 was captured, so no order could be created. This should be rare now that the SteamID field only accepts digits (see src/stripe.js), but any historical or edge-case entries land here instead of vanishing silently. Look up the customer via the Stripe Dashboard (payment intent / email below) to get the right SteamID, then resolve here — this creates the order and queues delivery immediately.
  </p>
  <table class="admin-table">
    <thead><tr><th>Date</th><th>Session</th><th>Items</th><th>Email</th><th>Amount</th><th>Reason</th><th>Resolve</th></tr></thead>
    <tbody>${rows || `<tr><td colspan="7" class="muted">Nothing unresolved 🎉</td></tr>`}</tbody>
  </table>
  `,
  });
}

// ============================================================
// Support tickets
// ============================================================

const ADMIN_TICKET_STATUS_BADGE = {
  open: '<span class="badge badge-warning">Open</span>',
  pending: '<span class="badge badge-warning">Awaiting You</span>',
  resolved: '<span class="badge badge-active">Resolved</span>',
  closed: '<span class="badge badge-muted">Closed</span>',
};

const ADMIN_TICKET_CATEGORY_LABELS = { general: "General", billing: "Billing", bug: "Bug Report", ban_appeal: "Ban Appeal", other: "Other" };

export function renderTicketsAdmin({ storeName, tickets, statusFilter, flash }) {
  const filterLink = (value, label) =>
    `<a href="/admin/tickets${value ? `?status=${value}` : ""}" class="${(statusFilter || "") === value ? "active" : ""}" style="margin-right:14px;">${label}</a>`;

  const rows = tickets.length
    ? tickets
        .map(
          (t) => `
    <tr>
      <td><a href="/admin/tickets/${t.id}">${esc(t.subject)}</a></td>
      <td class="mono">${esc(t.steamid)}</td>
      <td>${esc(ADMIN_TICKET_CATEGORY_LABELS[t.category] || t.category)}</td>
      <td>${ADMIN_TICKET_STATUS_BADGE[t.status] || esc(t.status)}</td>
      <td>${fmtDate(t.updated_at)}</td>
    </tr>`
        )
        .join("")
    : `<tr><td colspan="5" class="muted">No tickets here.</td></tr>`;

  const body = `
  <div class="admin-header-row">
    <h1>Support Tickets</h1>
  </div>
  <div style="margin-bottom:16px; font-family:var(--mono); font-size:13px;">
    ${filterLink("", "All")}${filterLink("open", "Open")}${filterLink("pending", "Awaiting You")}${filterLink("resolved", "Resolved")}${filterLink("closed", "Closed")}
  </div>
  <table class="admin-table">
    <thead><tr><th>Subject</th><th>SteamID</th><th>Category</th><th>Status</th><th>Updated</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>
  `;
  return adminLayout({ storeName, active: "/admin/tickets", body, flash });
}

export function renderTicketThreadAdmin({ storeName, ticket, messages, flash }) {
  const messageRows = messages
    .map(
      (m) => `
    <div class="ticket-message" style="padding:14px 16px; border-radius:8px; border:1px solid var(--border); background:var(--bg-panel-2); margin-bottom:12px; ${m.author_type === "admin" ? "border-left:3px solid var(--red);" : ""}">
      <div style="font-family:var(--mono); font-size:12px; margin-bottom:8px;"><strong>${m.author_type === "admin" ? "Support Team" : "Player"}</strong> <span class="muted">${fmtDate(m.created_at)}</span></div>
      <div style="font-size:14px; line-height:1.55; white-space:pre-wrap;">${esc(m.body)}</div>
    </div>`
    )
    .join("");

  const statusOptions = ["open", "pending", "resolved", "closed"]
    .map((s) => `<option value="${s}" ${ticket.status === s ? "selected" : ""}>${s.charAt(0).toUpperCase() + s.slice(1)}</option>`)
    .join("");

  const body = `
  <div class="admin-header-row">
    <h1>${esc(ticket.subject)}</h1>
  </div>
  <p class="muted" style="margin-top:-10px;">
    SteamID: <span class="mono">${esc(ticket.steamid)}</span>
    ${ticket.customer_email ? ` &nbsp;·&nbsp; ${esc(ticket.customer_email)}` : ""}
    &nbsp;·&nbsp; ${esc(ADMIN_TICKET_CATEGORY_LABELS[ticket.category] || ticket.category)}
  </p>

  <div class="admin-panel" style="margin-bottom:20px; max-width:720px;">
    ${messageRows}

    <form method="POST" action="/admin/tickets/${ticket.id}/reply" class="admin-form" style="margin-top:6px;">
      <textarea name="body" rows="4" placeholder="Reply to the player..." required></textarea>
      <button class="btn" type="submit" style="margin-top:10px;">Send Reply</button>
    </form>
  </div>

  <div class="admin-panel" style="max-width:720px;">
    <h2 style="margin-top:0;">Status</h2>
    <form method="POST" action="/admin/tickets/${ticket.id}/status" class="admin-form">
      <select name="status">${statusOptions}</select>
      <button class="btn secondary" type="submit" style="margin-top:10px;">Update Status</button>
    </form>
  </div>

  <p style="margin-top:20px;"><a href="/admin/tickets">&larr; Back to Tickets</a></p>
  `;
  return adminLayout({ storeName, active: "/admin/tickets", body, flash });
}
